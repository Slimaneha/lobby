<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        
      <link href="https://fonts.googleapis.com/css?family=Anton|Fresca|Oswald" rel="stylesheet">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
          <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
       

        
        		<!-- Images Type  -->
        <!-- <img src="http://placehold.it/350x150" alt=""> -->
        	<!-- Fin Images Type  -->

                <!-- Start Of nav barre  -->
        <header class="">
                <nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse ">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="default.php"> <img src="img/logo.png" alt="Logo"></a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="default.php">Lobby <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Blog</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tuto.html">Help</a>

      </li>
      </ul>
        </div>
        </nav>
</header>

            <!-- OF NAV barre  -->

            <!-- Carousel -->
            <div id="carouselExampleIndicators" class="carousel slide container-fluid" data-ride="carousel">
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item">
      <img class="d-block img-fluid" src="img/bg2.png">
    </div>
    <div class="carousel-item active">
      <img class="d-block img-fluid " src="img/bg3.png">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  



    <!-- Jeux Laura  -->
            <div class="container centre">
            <div class="card">

              <h4 class="card-title">Shark evolution</h4>
  <img class="card-img-top img-fluid" src="img/slcak1.jpg" alt="Card image cap">
  <div class="card-block">
    
    <p class="card-text">
     Prenez le contrôle d'un requin très affamé et faites un ravage de l'océan frénétique! 
     Survivre le plus longtemps possible en mangeant tout et tout le monde sur votre chemin! 
     Explorez les mondes sous-marins remplis de créatures délicieuses et exotiques! Recueillez 
     et évoluez des requins iconiques comme le Great White, Hammerhead et Megalodon! <br>
      <br>
     Lobby Effectuez par Amstrdmer  <br>
     disponibilité <span class="badge-success">Disponible </span>
    </p>
    <br>
    <img class="float-left" src="img/dis.jpg" alt="">
   <a href="shark.html"><button type="button" class="btn btn-success droite" data-toggle="modal" data-target="#exampleModal">  Voir l'offre </button></a> 
      
      </div>
    </div>    

    <!-- Fin  Jeux laura  -->

    <!-- Debut jeux Slimane  -->

            <div class="card">

              <h4 class="card-title">Real racing 3</h4>
  <img class="card-img-top img-fluid" src="img/ra.jpg" alt="Card image cap">
  <div class="card-block">
    
    <p class="card-text">
     Real Racing 3 est une franchise récompensée qui révolutionne les jeux de 
     course sur mobile. L'application propose des achats intégrés. Vous pouvez les
      désactiver dans les paramètres de votre appareil. Plus de 200 millions de téléchargements !
       Tabby Awards 2014 – LAURÉAT du meilleur jeu d'action, aventure, arcade et course
        Mobile Excellence Awards – LAURÉAT du meilleur jeu 2013 Game

 <br>
      <br>
     Lobby Effectuez par Slimane  <br>
     disponibilité <span class="badge-success">Disponible </span>
    </p>
    <br>
    <img class="float-left" src="img/dis.jpg" alt="">
   <a href="real.html"><button type="button" class="btn btn-success droite" data-toggle="modal" data-target="#exampleModal">  Voir l'offre </button></a> 
     
      </div>
    </div>    
 
 
 
 
 
 
 
  </div> 



 

  <div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-6">Lobby Phone 2017 tout droit réservé </h1>
    <p class="lead"> Equipe : Slimane & Amstrdmer </p>
    <figure class="centre"> 
    <img class="img-fluid" src="img/prix.png" alt="">
    <img class="img-fluid" src="img/paiment.jpg" alt="">
    <img class="img-fluid" src="img/youpass-logo-white.png" alt="">
  </figure>

  </div>
</div>


      <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script>
        window.jQuery || document.write('<script src="js/vendor/jquery-1.12.0.min.js"><\/script>')
    </script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="https://use.fontawesome.com/a0c828b765.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
         <script>
                (function (i, s, o, g, r, a, m) {
                    i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                        (i[r].q = i[r].q || []).push(arguments)
                    }, i[r].l = 1 * new Date(); a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
                })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-101732323-1', 'auto');
            ga('send', 'pageview');
        </script>
      
    </body>
</html>
