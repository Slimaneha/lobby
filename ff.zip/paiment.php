<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>validé</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->
          <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        
    <header class="">
                <nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse ">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#"> <img src="img/logo.png" alt="Logo"></a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Lobby <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="blog.html">Blog</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tuto.html">Help</a>

      </li>
      </ul>
        </div>
        </nav>
</header>


    <!--And Nav Bare -->

    <div class="media">
        <img src="" alt="">
  <img class="d-flex mr-3" src="img/good.png" alt="GODDDD ">
  <div class="media-body">
    <h5 class="mt-0 text-success">Paiement validé</h5>
     <p class="centre text-success"> Merci de votre achat et de votre confiance <br>
            Envoyer votre code par mail à l'adresse suivante <strong> phoneactut@gmail.com</strong>  <br>
             votre commande sera traité dans un delait de 48H  <br>
            si vous avez des questions  , merci de nous contacter par Email à l'adresse suivante 
            phoneactut@gmail.com  Pour retourner à l'accueil <a href="default.php">Cliquez ici  </a> </p>
  </div>
</div>
<!--    
        <div>
           

        </div>-->
    <figure class="container-fluid">
        <img class="img-fluid" src="img/bg1.png" alt="Bg ">
    </figure>



      <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script>
        window.jQuery || document.write('<script src="js/vendor/jquery-1.12.0.min.js"><\/script>')
    </script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="https://use.fontawesome.com/a0c828b765.js"></script>
        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
    </body>
</html>
